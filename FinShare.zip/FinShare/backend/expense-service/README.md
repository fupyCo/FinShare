# FinShare expense-service

This service is not yet implemented. 

See the auth-service for an example of the structure.

## To implement:
1. Copy the auth-service structure
2. Update package.json name
3. Implement the service-specific routes

